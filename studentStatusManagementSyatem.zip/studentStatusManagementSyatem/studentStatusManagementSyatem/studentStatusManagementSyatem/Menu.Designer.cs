﻿namespace studentStatusManagementSyatem
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.专业管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.班级管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.学生管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.课程管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.成绩管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.系统管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.添加专业ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.专业浏览ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.添加班级ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.班级浏览ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.添加学生ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.学生浏览ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.添加课程ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.课程浏览ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.录入成绩ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.成绩浏览ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.成绩查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出系统ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.page = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.专业管理ToolStripMenuItem,
            this.班级管理ToolStripMenuItem,
            this.学生管理ToolStripMenuItem,
            this.课程管理ToolStripMenuItem,
            this.成绩管理ToolStripMenuItem,
            this.系统管理ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 专业管理ToolStripMenuItem
            // 
            this.专业管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.添加专业ToolStripMenuItem,
            this.专业浏览ToolStripMenuItem});
            this.专业管理ToolStripMenuItem.Name = "专业管理ToolStripMenuItem";
            this.专业管理ToolStripMenuItem.Size = new System.Drawing.Size(83, 24);
            this.专业管理ToolStripMenuItem.Text = "专业管理";
            // 
            // 班级管理ToolStripMenuItem
            // 
            this.班级管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.添加班级ToolStripMenuItem,
            this.班级浏览ToolStripMenuItem});
            this.班级管理ToolStripMenuItem.Name = "班级管理ToolStripMenuItem";
            this.班级管理ToolStripMenuItem.Size = new System.Drawing.Size(83, 24);
            this.班级管理ToolStripMenuItem.Text = "班级管理";
            // 
            // 学生管理ToolStripMenuItem
            // 
            this.学生管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.添加学生ToolStripMenuItem,
            this.学生浏览ToolStripMenuItem});
            this.学生管理ToolStripMenuItem.Name = "学生管理ToolStripMenuItem";
            this.学生管理ToolStripMenuItem.Size = new System.Drawing.Size(83, 24);
            this.学生管理ToolStripMenuItem.Text = "学生管理";
            // 
            // 课程管理ToolStripMenuItem
            // 
            this.课程管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.添加课程ToolStripMenuItem,
            this.课程浏览ToolStripMenuItem});
            this.课程管理ToolStripMenuItem.Name = "课程管理ToolStripMenuItem";
            this.课程管理ToolStripMenuItem.Size = new System.Drawing.Size(83, 24);
            this.课程管理ToolStripMenuItem.Text = "课程管理";
            // 
            // 成绩管理ToolStripMenuItem
            // 
            this.成绩管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.录入成绩ToolStripMenuItem,
            this.成绩浏览ToolStripMenuItem,
            this.成绩查询ToolStripMenuItem});
            this.成绩管理ToolStripMenuItem.Name = "成绩管理ToolStripMenuItem";
            this.成绩管理ToolStripMenuItem.Size = new System.Drawing.Size(83, 24);
            this.成绩管理ToolStripMenuItem.Text = "成绩管理";
            // 
            // 系统管理ToolStripMenuItem
            // 
            this.系统管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.退出系统ToolStripMenuItem});
            this.系统管理ToolStripMenuItem.Name = "系统管理ToolStripMenuItem";
            this.系统管理ToolStripMenuItem.Size = new System.Drawing.Size(83, 24);
            this.系统管理ToolStripMenuItem.Text = "系统管理";
            // 
            // 添加专业ToolStripMenuItem
            // 
            this.添加专业ToolStripMenuItem.Name = "添加专业ToolStripMenuItem";
            this.添加专业ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.添加专业ToolStripMenuItem.Text = "添加专业";
            this.添加专业ToolStripMenuItem.Click += new System.EventHandler(this.添加专业ToolStripMenuItem_Click);
            // 
            // 专业浏览ToolStripMenuItem
            // 
            this.专业浏览ToolStripMenuItem.Name = "专业浏览ToolStripMenuItem";
            this.专业浏览ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.专业浏览ToolStripMenuItem.Text = "专业浏览";
            this.专业浏览ToolStripMenuItem.Click += new System.EventHandler(this.专业浏览ToolStripMenuItem_Click);
            // 
            // 添加班级ToolStripMenuItem
            // 
            this.添加班级ToolStripMenuItem.Name = "添加班级ToolStripMenuItem";
            this.添加班级ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.添加班级ToolStripMenuItem.Text = "添加班级";
            this.添加班级ToolStripMenuItem.Click += new System.EventHandler(this.添加班级ToolStripMenuItem_Click);
            // 
            // 班级浏览ToolStripMenuItem
            // 
            this.班级浏览ToolStripMenuItem.Name = "班级浏览ToolStripMenuItem";
            this.班级浏览ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.班级浏览ToolStripMenuItem.Text = "班级浏览";
            this.班级浏览ToolStripMenuItem.Click += new System.EventHandler(this.班级浏览ToolStripMenuItem_Click);
            // 
            // 添加学生ToolStripMenuItem
            // 
            this.添加学生ToolStripMenuItem.Name = "添加学生ToolStripMenuItem";
            this.添加学生ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.添加学生ToolStripMenuItem.Text = "添加学生";
            this.添加学生ToolStripMenuItem.Click += new System.EventHandler(this.添加学生ToolStripMenuItem_Click);
            // 
            // 学生浏览ToolStripMenuItem
            // 
            this.学生浏览ToolStripMenuItem.Name = "学生浏览ToolStripMenuItem";
            this.学生浏览ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.学生浏览ToolStripMenuItem.Text = "学生浏览";
            this.学生浏览ToolStripMenuItem.Click += new System.EventHandler(this.学生浏览ToolStripMenuItem_Click);
            // 
            // 添加课程ToolStripMenuItem
            // 
            this.添加课程ToolStripMenuItem.Name = "添加课程ToolStripMenuItem";
            this.添加课程ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.添加课程ToolStripMenuItem.Text = "添加课程";
            this.添加课程ToolStripMenuItem.Click += new System.EventHandler(this.添加课程ToolStripMenuItem_Click);
            // 
            // 课程浏览ToolStripMenuItem
            // 
            this.课程浏览ToolStripMenuItem.Name = "课程浏览ToolStripMenuItem";
            this.课程浏览ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.课程浏览ToolStripMenuItem.Text = "课程浏览";
            this.课程浏览ToolStripMenuItem.Click += new System.EventHandler(this.课程浏览ToolStripMenuItem_Click);
            // 
            // 录入成绩ToolStripMenuItem
            // 
            this.录入成绩ToolStripMenuItem.Name = "录入成绩ToolStripMenuItem";
            this.录入成绩ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.录入成绩ToolStripMenuItem.Text = "录入成绩";
            this.录入成绩ToolStripMenuItem.Click += new System.EventHandler(this.录入成绩ToolStripMenuItem_Click);
            // 
            // 成绩浏览ToolStripMenuItem
            // 
            this.成绩浏览ToolStripMenuItem.Name = "成绩浏览ToolStripMenuItem";
            this.成绩浏览ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.成绩浏览ToolStripMenuItem.Text = "成绩浏览";
            this.成绩浏览ToolStripMenuItem.Click += new System.EventHandler(this.成绩浏览ToolStripMenuItem_Click);
            // 
            // 成绩查询ToolStripMenuItem
            // 
            this.成绩查询ToolStripMenuItem.Name = "成绩查询ToolStripMenuItem";
            this.成绩查询ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.成绩查询ToolStripMenuItem.Text = "成绩查询";
            // 
            // 退出系统ToolStripMenuItem
            // 
            this.退出系统ToolStripMenuItem.Name = "退出系统ToolStripMenuItem";
            this.退出系统ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.退出系统ToolStripMenuItem.Text = "退出系统";
            this.退出系统ToolStripMenuItem.Click += new System.EventHandler(this.退出系统ToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.page});
            this.statusStrip1.Location = new System.Drawing.Point(0, 424);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(800, 26);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(308, 20);
            this.toolStripStatusLabel1.Text = "欢迎使用本学生学籍管理系统                          ";
            // 
            // page
            // 
            this.page.Name = "page";
            this.page.Size = new System.Drawing.Size(39, 20);
            this.page.Text = "主页";
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Menu";
            this.Text = "学生学籍管理系统";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 专业管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 添加专业ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 专业浏览ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 班级管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 添加班级ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 班级浏览ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 学生管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 添加学生ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 学生浏览ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 课程管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 添加课程ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 课程浏览ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 成绩管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 录入成绩ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 成绩浏览ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 成绩查询ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 系统管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出系统ToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel page;
    }
}