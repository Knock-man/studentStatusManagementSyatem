/*
SQLyog Ultimate v12.09 (64 bit)
MySQL - 5.5.62 : Database - studentstatusmanagement
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`studentstatusmanagement` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `studentstatusmanagement`;

/*Table structure for table `choose` */

DROP TABLE IF EXISTS `choose`;

CREATE TABLE `choose` (
  `courseId` char(10) NOT NULL,
  `studentId` char(10) NOT NULL,
  `grade` char(10) DEFAULT NULL,
  PRIMARY KEY (`courseId`,`studentId`),
  KEY `studentId` (`studentId`),
  CONSTRAINT `choose_ibfk_1` FOREIGN KEY (`courseId`) REFERENCES `course` (`courseId`),
  CONSTRAINT `choose_ibfk_2` FOREIGN KEY (`studentId`) REFERENCES `student` (`studentId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `choose` */

insert  into `choose`(`courseId`,`studentId`,`grade`) values ('101','2350180318','100');

/*Table structure for table `class` */

DROP TABLE IF EXISTS `class`;

CREATE TABLE `class` (
  `classId` char(10) NOT NULL,
  `className` char(10) DEFAULT NULL,
  `classCount` char(10) DEFAULT NULL,
  `classExplain` char(30) DEFAULT NULL,
  `teacher` char(10) DEFAULT NULL,
  `majorId` char(10) DEFAULT NULL,
  PRIMARY KEY (`classId`),
  KEY `majorId` (`majorId`),
  CONSTRAINT `class_ibfk_1` FOREIGN KEY (`majorId`) REFERENCES `major` (`majorId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `class` */

insert  into `class`(`classId`,`className`,`classCount`,`classExplain`,`teacher`,`majorId`) values ('20501803','软工三班','36','好好学习，天天向上','刘德华','235018');

/*Table structure for table `course` */

DROP TABLE IF EXISTS `course`;

CREATE TABLE `course` (
  `courseId` char(10) NOT NULL,
  `courseGrade` char(10) DEFAULT NULL,
  `courseName` char(10) DEFAULT NULL,
  `courseExplain` char(30) DEFAULT NULL,
  PRIMARY KEY (`courseId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `course` */

insert  into `course`(`courseId`,`courseGrade`,`courseName`,`courseExplain`) values ('101','3','C#','支持窗体设计的语言');

/*Table structure for table `major` */

DROP TABLE IF EXISTS `major`;

CREATE TABLE `major` (
  `majorId` char(10) NOT NULL,
  `majorName` char(10) DEFAULT NULL,
  `majorExplain` char(30) DEFAULT NULL,
  PRIMARY KEY (`majorId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `major` */

insert  into `major`(`majorId`,`majorName`,`majorExplain`) values ('235018','软件工程','学技术');

/*Table structure for table `student` */

DROP TABLE IF EXISTS `student`;

CREATE TABLE `student` (
  `studentId` char(10) NOT NULL,
  `studentName` char(10) DEFAULT NULL,
  `sex` char(10) DEFAULT NULL,
  `age` char(10) DEFAULT NULL,
  `studentExplain` char(30) DEFAULT NULL,
  `classId` char(10) DEFAULT NULL,
  PRIMARY KEY (`studentId`),
  KEY `classId` (`classId`),
  CONSTRAINT `student_ibfk_1` FOREIGN KEY (`classId`) REFERENCES `class` (`classId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `student` */

insert  into `student`(`studentId`,`studentName`,`sex`,`age`,`studentExplain`,`classId`) values ('2350180318','小杰','男','20','爱编程','20501803');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `userName` char(20) DEFAULT NULL,
  `userPassword` char(20) DEFAULT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `user` */

insert  into `user`(`userId`,`userName`,`userPassword`) values (1,'jiejie','123'),(2,'jie','123');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
